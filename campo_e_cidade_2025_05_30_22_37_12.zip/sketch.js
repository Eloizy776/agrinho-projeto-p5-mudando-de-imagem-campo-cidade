let campo;
let cidade;
let estado = true;
function preload() {
  campo = loadImage('https://picsum.photos/400/400?random=1');
  cidade = loadImage('https://picsum.photos/400/400?random=2');
}

function setup() {
  createCanvas(400, 400);
  background(campo);
}

function draw() {
  if (estado) {
    image(campo, 0, 0, width, height);
  } else {
    image(cidade, 0, 0, width, height);
  }
}

function mousePressed() {
  estado = !estado;
}